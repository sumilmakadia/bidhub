 <div class="maintopbanner">
   <div class="carousel-caption d-none d-md-block" style="top: 107px;"><h1 class="mb-4">Under Construction</h1></div>
     
 </div>
 <div class="hb" style="min-height:0!important;">
        <div id="hb" class="carousel slide" data-ride="carousel">
            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img src="{{ asset('storage/company/images/home_banner.jpg')}}" class="d-block w-100 img-fluid" alt="hb">
                    <div class="carousel-caption d-none d-md-block">
                        <h1 class="mb-4">America's C2C<sup><small>™</small></sup> Resource</h1>
                        <!--<h1 class="mb-4">{{setting('home.location_2')}}</h1>-->
                        <!--<h4 class="text-uppercase">{{setting('home.location_3')}}</h4>-->
                        <h4 class="text-uppercase">CONNECTING CONTRACTORS TO CONTRACTORS</h4>
                        <!--<p class="mb-4 text-uppercase">{{setting('home.location_3')}}</p>-->
                        <p class="mb-4 text-uppercase">YOUR COMMUNITY. ONE SOURCE. THAT SIMPLE</p>
                        <a class="btn btn-theme" href="/register">Try for free</a>
                    </div>

                </div>
            </div>
        </div>
    </div>
    
    <style>
        
        .maintopbanner{    position: relative; margin-top: 89px; height:350px; width:100%; background-color:#ffcf3b; }
        .maintopbanner h1{ color:#000; font-weight:bold; }
        
        
        
    </style>