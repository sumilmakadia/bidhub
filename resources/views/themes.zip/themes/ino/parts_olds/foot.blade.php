<script type="text/javascript" src="{{$assets_path_public}}/js/jquery-2.2.4.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<!--waypoint js-->
<script type="text/javascript" src="{{$assets_path_public}}/vendors/waypoints/waypoints.min.js"></script>
<!--nav js-->
<script type="text/javascript" src="{{$assets_path_public}}/js/jquery-nav.js"></script>
<!--counterup js-->
<script type="text/javascript" src="{{$assets_path_public}}/vendors/counterup/jquery.counterup.min.js"></script>
<!--isotope js-->
<script type="text/javascript" src="{{$assets_path_public}}/vendors/isotope/isotope-min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/js/jquery.stellar.js"></script>
<!--imagesloaded js-->

<script type="text/javascript" src="{{$assets_path_public}}/vendors/imagesloaded/imagesloaded.pkgd.min.js"></script>
<!--magnific js-->
<script type="text/javascript" src="{{$assets_path_public}}/vendors/magnific-popup/jquery.magnific-popup.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/js/plugins.js"></script>
<!-- REVOLUTION JS FILES -->
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/jquery.themepunch.tools.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/jquery.themepunch.revolution.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/revolution-addons/countdown/revolution.addon.countdown.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/revolution-addons/typewriter/js/revolution.addon.typewriter.min.js"></script>
<!-- SLIDER REVOLUTION 5.0 EXTENSIONS  (Load Extensions only on Local File Systems !  The following part can be removed on Server for On Demand Loading) -->
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.carousel.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.parallax.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/vendors/revolution/js/extensions/revolution.extension.video.min.js"></script>
<!--wow js-->
<script type="text/javascript" src="{{$assets_path_public}}/js/wow.min.js"></script>
<!-- owl JS Files -->
<script type="text/javascript" src="{{$assets_path_public}}/vendors/owl-carousel/owl.carousel.min.js"></script>
<script type="text/javascript" src="{{$assets_path_public}}/js/custom.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script>
 


</script>


<style type="text/css">
    @media (min-width: 1367px){.h-dark-testi{padding:9rem 10rem 12rem 12rem}}@media (max-width: 767.98px){.hb .followus{display:none}}@media (max-width: 991.98px){.hb .carousel-caption{padding-bottom:15%}.skillgap-bg{background:none;text-align:center}.h-dark-testi{position:relative;padding:5rem}.h-red-testi{padding:5rem;margin-right:0}.approch-bg .enskill{position:relative;width:100%;padding:5rem;top:0}}@media (min-width: 993px) and (min-width: 1024px){.h-dark-testi{padding:4rem 8rem}}

/*# sourceMappingURL=rwd.css.map */

@import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700|Ubuntu:300,400,500,700&display=swap");body{background:#fff;font-family:'Montserrat', sans-serif}p{font-size:15px}.text-blue{color:#517fdb}h1{font-size:4rem;font-weight:300}.bg-red{background:#ff0000}.bg-dark{background:#282828}.btn{border-radius:2rem}.btn-theme{background:#ed9a7c;color:#fff;font-weight:500}.btn-theme:hover{color:#fff;background:#282828}a{position:relative}a .link{padding-top:10px}a .link:before{left:0;bottom:0;width:100%;height:2px;background:#0883a4;-webkit-transform:scaleX(0);transform:scaleX(0)}a .link:hover:before{-webkit-transform:scaleX(1);transform:scaleX(1)}.ptb-5{padding-top:5rem;padding-bottom:5rem}.p-10{padding:5rem !important}.mb-10{margin-bottom:5rem}header{background:#517fdb}header .navbar-light .navbar-nav .nav-link{color:#fff;padding-right:1rem;padding-left:1rem}header nav{color:#fff;font-size:14px}header nav:hover{color:#ff0000}.hb{position:relative}.hb .carousel-caption{left:15%;right:15%;bottom:30%}.hb .carousel-caption p{font-size:16px}.hb .carousel-caption a.link{color:#fff;text-transform:uppercase;font-size:13px;padding:10px}footer{background:#333;color:#fff;padding-top:15px;padding-bottom:15px;font-size:13px}footer a{color:#fff;margin:10px}

/*# sourceMappingURL=style.css.map */
</style>