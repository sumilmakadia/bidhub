@if(Request::path() == '/')

<header class="header" role="banner">
 <!--   <div class="nav-item" style="background-color:#000;">-->
	<!--    <div class="nav-link d-none d-lg-block d-md-block waves-effect waves-dark" style="padding: 8px 10px 5px;line-height: 16px;color:#fff;text-align:center;">-->
	<!--        Site is in beta testing.  Please feel free to explore the site, launch will be coming soon.-->
	<!--    </div>-->
	<!--</div>-->
	<div class="col-md-12">
	    <nav class="navbar navbar-expand-lg navbar-light">
	    	
				<a class="navbar-brand" href="/">
				<img src="{{$assets_path_public_eli}}images/bidhub-logo-blue.png" alt="">

				</a>


				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

                

			<!--========== Collect the nav links, forms, and other content for toggling ==========-->
			<!--<ul class="nav navbar-nav nav-right navbar-right">-->
			<!--	<li>-->
			<!--		<a href="/app/login" class="btn g-btn">-->
			<!--			Login-->
			<!--		</a>-->
			<!--	</li>-->
			<!--	<li>-->
			<!--		<a href="/app/register" class="btn g-btn">-->
			<!--			Try For Free-->
			<!--		</a>-->
			<!--	</li>-->
			<!--</ul>-->

			
			<div class="collapse navbar-collapse" id="navbarTogglerDemo03">

				<ul class="navbar-nav pl-5 ml-5">

					<li class="nav-item "><a href="#." class="nav-link" target="_self"><span>About</span></a></li>
					<li class="nav-item "><a href="#." class="nav-link" target="_self"><span>Community</span></a></li>
					<li class="nav-item "><a href="#." class="nav-link" target="_self"><span>How it works</span></a></li>
					
				</ul>

				

				<ul class="navbar-nav pl-5 ml-5 ml-auto">

					<li class="nav-item srchlist"> 
						<form action="" class="search-form">
							<div class="form-group has-feedback">
								<label for="search" class="sr-only">Search</label>
								<input type="text" class="form-control" name="search" id="search" placeholder="search">	<img src="{{asset('assets/landings/eli/images/search.png')}}" class="form-control-feedback cussrchicon"><!-- <span class="fa fa-search form-control-feedback"></span> -->
							</div>
						</form>
					</li>

					<li><a href="/login" class="btn btn btn-outline-light-custom text-uppercase ml-3">Login &nbsp; <i class="fa fa-user"></i></a></li>

				</ul>

			</div><!-- /.navbar-collapse -->


		
        </nav>
	</div>
	<style>
.cussrchicon{width: 20px;
    position: absolute;
    top: 6px;
    right: 9px;}
.search-form .form-group {
  float: right !important;
  transition: all 0.35s, border-radius 0s;
  width: 32px;
  height: 32px;
  border-radius: 25px;
  
}
.search-form .form-group input.form-control {
  padding-right: 20px;
  border: 0 none;
  background: transparent;
  box-shadow: none;
  display:block;
  padding-top:0px !important; 
}
.search-form .form-group:hover,
.search-form .form-group.hover {
  width: 100%;
  border-radius: 4px 25px 25px 4px;
   background-color: #fff;
  box-shadow: 0 1px 1px rgba(0, 0, 0, 0.075) inset;
  border: 1px solid #ccc;
}

form.search-form {
    margin: 5px;
    position: relative;
}

.search-form .form-group span.form-control-feedback {
  position: absolute;
  top: -1px;
  right: -2px;
  z-index: 2;
  display: block;
  width: 34px;
  height: 34px;
  line-height: 34px;
  text-align: center;
  color: #1e1e1c;
  left: initial;
  font-size: 20px;
}



	    .header.fadeInDown .navbar {
	        background-color:white!important;
	    }
	    header .navbar-light .navbar-nav .nav-link {
	        text-transform: uppercase;
	    }
	    .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .show>.nav-link {
    color: #fff;
}
.btn-outline-light-custom{ border:2px solid #000;  font-size: 14px;     position: relative; top: 7px;}
.btn-outline-light-custom .fa {
    border-radius: 90px;
    width: 20px;
    height: 20px;
    border: 1px solid #9f9f9f;
    padding: 2px;
    color: #9f9f9f;
}
.hb .carousel-caption{z-index: 1;}
.srchlist{position: relative; top:7px;}
.srchlist .fa-search{font-size: 24px; }


@import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700|Ubuntu:300,400,500,700&display=swap");body{background:#fff;font-family:'Montserrat', sans-serif}p{font-size:15px}.text-blue{color:#517fdb}h1{font-size:4rem;font-weight:300}.bg-red{background:#ff0000}.bg-dark{background:#282828}.btn{border-radius:2rem}.btn-theme{background:#ed9a7c;color:#fff;font-weight:500}.btn-theme:hover{color:#fff;background:#282828}a{position:relative}a .link{padding-top:10px}a .link:before{left:0;bottom:0;width:100%;height:2px;background:#0883a4;-webkit-transform:scaleX(0);transform:scaleX(0)}a .link:hover:before{-webkit-transform:scaleX(1);transform:scaleX(1)}.ptb-5{padding-top:5rem;padding-bottom:5rem}.p-10{padding:5rem !important}.mb-10{margin-bottom:5rem}header{background:transparent;}header .navbar-light .navbar-nav .nav-link{color:#000;padding-right:1rem;padding-left:1rem}header nav{color:#fff;font-size:14px}header nav:hover{color:#ff0000}.hb{position:relative}.hb .carousel-caption{left:15%;right:15%;bottom:30%}.hb .carousel-caption p{font-size:16px}.hb .carousel-caption a.link{color:#fff;text-transform:uppercase;font-size:13px;padding:10px}footer{background:#333;color:#fff;padding-top:15px;padding-bottom:15px;font-size:13px}footer a{color:#fff;margin:10px}

	</style>
</header>



@else

<header class="header" role="banner">
 <!--   <div class="nav-item" style="background-color:#000;">-->
	<!--    <div class="nav-link d-none d-lg-block d-md-block waves-effect waves-dark" style="padding: 8px 10px 5px;line-height: 16px;color:#fff;text-align:center;">-->
	<!--        Site is in beta testing.  Please feel free to explore the site, launch will be coming soon.-->
	<!--    </div>-->
	<!--</div>-->
	<div class="container">
	    <nav class="navbar navbar-expand-lg navbar-light">
	    	
				<a class="navbar-brand" href="/">
				<img src="{{$assets_path_public_eli}}images/bidhub.png" alt="">

				</a>
				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>

			<!--========== Collect the nav links, forms, and other content for toggling ==========-->
			<!--<ul class="nav navbar-nav nav-right navbar-right">-->
			<!--	<li>-->
			<!--		<a href="/app/login" class="btn g-btn">-->
			<!--			Login-->
			<!--		</a>-->
			<!--	</li>-->
			<!--	<li>-->
			<!--		<a href="/app/register" class="btn g-btn">-->
			<!--			Try For Free-->
			<!--		</a>-->
			<!--	</li>-->
			<!--</ul>-->
			<div class="collapse navbar-collapse" id="navbarTogglerDemo03">

				<ul class="navbar-nav ml-auto">
					@php

						if (Voyager::translatable($items)) {
						    $items = $items->load('translations');
						}

					@endphp

					@foreach ($items as $item)
                        
                        @if($item->title != 'About Us')
                        
						@php
						
						    

							$originalItem = $item;
							if (Voyager::translatable($item)) {
							    $item = $item->translate($options->locale);
							}

							$isActive = null;
							$styles = null;
							$icon = null;

							// Background Color or Color
							if (isset($options->color) && $options->color == true) {
							    $styles = 'color:'.$item->color;
							}
							if (isset($options->background) && $options->background == true) {
							    $styles = 'background-color:'.$item->color;
							}

							// Check if link is current
							if(url($item->link()) == url()->current()){
							    $isActive = 'active';
							}

							// Set Icon
							if(isset($options->icon) && $options->icon == true){
							    $icon = '<i class="' . $item->icon_class . '"></i>';
							}

						@endphp

						<li class="nav-item {{ $isActive }}">
							<a href="{{ url($item->link()) }}" class="nav-link" target="{{ $item->target }}" style="{{ $styles }}">
								{!! $icon !!}
								<span>{{ $item->title }}</span>
							</a>
							@if(!$originalItem->children->isEmpty())
								@include('voyager::menu.default', ['items' => $originalItem->children, 'options' => $options])
							@endif
						</li>
						
						@endif
						
					@endforeach
					<li><a href="/login" class="btn btn btn-outline-light text-uppercase ml-3">Login</a></li>
                    <li class="ml-md-2"><a href="/register" class="btn btn-theme pl-3 pr-3 text-uppercase">Try for free</a></li>
				
				</ul>
			</div><!-- /.navbar-collapse -->
		
        </nav>
	</div>
	<style>
	    .header.fadeInDown .navbar {
	        background-color:white!important;
	    }
	    header .navbar-light .navbar-nav .nav-link {
	        text-transform: uppercase;
	    }
	    .navbar-light .navbar-nav .active>.nav-link, .navbar-light .navbar-nav .nav-link.active, .navbar-light .navbar-nav .nav-link.show, .navbar-light .navbar-nav .show>.nav-link {
    color: #fff;
}

@import url("https://fonts.googleapis.com/css?family=Montserrat:400,500,600,700|Ubuntu:300,400,500,700&display=swap");body{background:#fff;font-family:'Montserrat', sans-serif}p{font-size:15px}.text-blue{color:#517fdb}h1{font-size:4rem;font-weight:300}.bg-red{background:#ff0000}.bg-dark{background:#282828}.btn{border-radius:2rem}.btn-theme{background:#ed9a7c;color:#fff;font-weight:500}.btn-theme:hover{color:#fff;background:#282828}a{position:relative}a .link{padding-top:10px}a .link:before{left:0;bottom:0;width:100%;height:2px;background:#0883a4;-webkit-transform:scaleX(0);transform:scaleX(0)}a .link:hover:before{-webkit-transform:scaleX(1);transform:scaleX(1)}.ptb-5{padding-top:5rem;padding-bottom:5rem}.p-10{padding:5rem !important}.mb-10{margin-bottom:5rem}header{background:#517fdb}header .navbar-light .navbar-nav .nav-link{color:#fff;padding-right:1rem;padding-left:1rem}header nav{color:#fff;font-size:14px}header nav:hover{color:#ff0000}.hb{position:relative}.hb .carousel-caption{left:15%;right:15%;bottom:30%}.hb .carousel-caption p{font-size:16px}.hb .carousel-caption a.link{color:#fff;text-transform:uppercase;font-size:13px;padding:10px}footer{background:#333;color:#fff;padding-top:15px;padding-bottom:15px;font-size:13px}footer a{color:#fff;margin:10px}
	</style>
</header>

@endif
