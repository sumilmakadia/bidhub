

 <section class="">
            <div class="row">
                <div class="col-md-12 text-center">
                <h2 class="mb-3">YEAH IT'S THAT SIMPLE - YOUR BLUEPRINT FOR SUCCESS!</h2>
                <img src="{{ asset('storage/company/images/blueprint.jpg')}}" alt="a" class="img-fluid">
                </div>
            </div>
    </section>