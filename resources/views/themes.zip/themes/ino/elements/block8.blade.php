<section class="support-area" style="background-color:#4281e2;!important">
	<div class="container">
		<div class="row">
		    <!--<div class="col-sm-12">-->
		    <!--    <div class="support-item wow fadeIn" data-wow-delay="0s" style="visibility: visible; animation-delay: 0s; animation-name: fadeIn; background:inherit; color:white; height:300px;">-->
		    <!--        <center><h1>{{setting('home.location_22')}}</h1></center>-->
		    <!--    </div>-->
		    <!--</div>-->
			<div class="col-sm-4">
				<div class="support-item wow fadeIn" data-wow-delay="0s" style="visibility: visible; animation-delay: 0s; animation-name: fadeIn; height:300px;">
					<i class="lnr lnr-envelope"></i>
					<h2>{{setting('home.location_30')}}</h2>
					<a href="mailto:support@bidhub.com" style="padding:10px;">{{setting('home.location_31')}}</a>
				</div>
			</div>
			<div class="col-sm-4">
				<div class="support-item wow fadeIn" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn; height:300px;">
					<i class="lnr lnr-phone-handset"></i>
					<h2>{{setting('home.location_32')}}</h2>
					<a href="tel:3042616482" style="padding:10px;">{{setting('home.location_33')}}</a>
				</div>
			</div>

			<div class="col-sm-4">
				<div class="support-item wow fadeIn" data-wow-delay="0.2s" style="visibility: visible; animation-delay: 0.2s; animation-name: fadeIn; height:300px;">
					<i class="lnr lnr-apartment"></i>
					<h2>{{setting('home.location_34')}}</h2>
					<a href="#" onclick="event.preventDefault();" style="padding:10px;">{{setting('home.location_35')}}</a>
				</div>
			</div>
		</div>
	</div>
</section>