<section class="call-action-area" data-stellar-background"ratio="2" style="background-position: -1px -230.578px;">
	<div class="container wow fadeInUp" style="visibility: visible; animation-name: fadeInUp;">
		<div class="call-action-text">
			{{setting('home.location_15')}}
		</div>
		<a href="/register" class="btn reg-btn">Try For Free</a>
	</div>
</section>