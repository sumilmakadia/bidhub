


  <section class="ptb-5">
        <div class="container">
            <div class="row mb-5">
                <div class="col-md-12 text-center">
                    <!--<h2>{{setting('home.location_4')}}</h2>-->
                    <!--<h3>{{setting('home.location_5')}}</h3>-->
                   
                        <h2> SELL. BUY. HIRE. FIND.</h2>
                      <h3>BE MORE PRODUCTIVE - MAKE MORE OUT OF LESS!</h3>
                    <h5>For Developers, Builders, General Contractors, Subcontractors and Real<br> Estate Agents that want to be more 
                    productive and make more out of less!</h5>
                </div>
            </div>
            <div class="row text-center">
                <div class="col-md-6 mb-5">
                   <h1 class="text-blue"><i class="ion-ios-person"></i></h1>
                    <h4>Join Our Community</h4>
                    <p>Join the many other businesses in our nationwide community for free Upgrade membership for premier benifits. </p>
                </div>
                  <div class="col-md-6 mb-5">
                    <h1 class="text-blue"><i class="ion-ios-medical"></i></h1>
                    <h4>Post projects, Jobs, Property, Equipment</h4>
                    <p>Need help? Looking for equipment? Want to sell property? Connect with the right workers, buyers and sellers in your community.</p>
                </div>
                  <div class="col-md-6 mb-5">
                    <h1 class="text-blue"><i class="ion-ios-checkmark-circle-outline"></i></h1>
                    <h4>Find Work, Get Hired Fast</h4>
                    <p>Searching for work? Check out projects that interest you, submit your proposal online, instant message for quick answers.</p>
                </div>
                  <div class="col-md-6 mb-5">
                    <h1 class="text-blue"><i class="ion-ios-trophy"></i></h1>
                    <h4>Raise Your Visibility, Get Noticed</h4>
                    <p>Enchance brand awarness with customized profiles to highlight your projects, interests and property for sale. </p>
                </div> 
            </div>
        </div>
    </section>
    