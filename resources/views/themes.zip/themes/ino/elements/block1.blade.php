
 <div class="hb" style="min-height:0!important;">
        <div id="hb" class="carousel slide" data-ride="carousel">

            <ul class="carousel-indicators">
            <li data-target="#hb" data-slide-to="0" class="active"></li>
            <li data-target="#hb" data-slide-to="1"></li>
            <li data-target="#hb" data-slide-to="2"></li>
            <li data-target="#hb" data-slide-to="3"></li>
            <li data-target="#hb" data-slide-to="4"></li>
            </ul>

            <div class="carousel-inner">
                <div class="carousel-item active">

                    <img src="{{ asset('storage/company/images/5-min.jpg')}}" class="d-block w-100 img-fluid" alt="hb">
                    <div class="carousel-caption sliderdata">
                    <h1>Contractors, <br> Come Together!</h1>
                    <p>Be more Productive. Be more <br>Profitable. Be more Successful.</p>
                    <button class="btn btn-warning lscbtn">Try it for free <img src="{{asset('storage/company/images/button_hand.png')}}" class="btnimg"></button>
                    </div>
                    
                    
                </div>
                
                <div class="carousel-item">

                    <img src="{{ asset('storage/company/images/2-min.jpg')}}" class="d-block w-100 img-fluid" alt="hb">
                    <div class="carousel-caption sliderdata" >
                    <h1>Businesses, <br> Come together! </h1>
                    <p>Join our nationwide directory <br> for free. Upgrade membership <br> for premier ad placement.</p>
                    <a href="{{url('/directory')}}" class="btn btn-warning lscbtn">Try it for free <img src="{{asset('storage/company/images/button_hand.png')}}" class="btnimg"></a>
                    </div>
                    
                </div>
                
                <div class="carousel-item">

                    <img src="{{ asset('storage/company/images/1-min.jpg')}}" class="d-block w-100 img-fluid" alt="hb">
                    <div class="carousel-caption sliderdata" >
                    <h1>Unlimited Projects, <br> More Bids! </h1>
                    <p> From alarms to utilities, upload <br> your project/plans to receive <br> unlimited bids from the pros.</p>
                    <a href="{{url('/project-room')}}" class="btn btn-warning lscbtn">Try it for free <img src="{{asset('storage/company/images/button_hand.png')}}" class="btnimg"></a>
                    </div>
                    
                </div>
                
                <div class="carousel-item">

                     <img src="{{ asset('storage/company/images/4-min.jpg')}}" class="d-block w-100 img-fluid" alt="hb">
                    <div class="carousel-caption sliderdata" >
                    <h1>Looking for Help ? <br> Come Right Here.</h1>
                    <p>Post in our Help Wanted section <br> to find new people to join <br> your company.</p>
                    <a href="{{url('/help-wanted')}}" class="btn btn-warning lscbtn">Try it for free <img src="{{asset('storage/company/images/button_hand.png')}}" class="btnimg"></a>
                    </div>
                    
                </div>
                
                <div class="carousel-item">

                     <img src="{{ asset('storage/company/images/3-min.jpg')}}" class="d-block w-100 img-fluid" alt="hb">
                    <div class="carousel-caption sliderdata" >
                    <h1>Building Materials & <br> Equipment for sale? </h1>
                    <p>Quickly post and sale Materials and <br> Equipment right in one place. </p>
                    <a href="{{url('/equipment-for-sale')}}" class="btn btn-warning lscbtn">Try it for free <img src="{{asset('storage/company/images/button_hand.png')}}" class="btnimg"></a>
                    </div>
                    
                </div>
                
               
               
            </div>
           <!--  <a class="carousel-control-prev" href="#hb" data-slide="prev">
                <span class="carousel-control-prev-icon"></span>
            </a>
              <a class="carousel-control-next" href="#hb" data-slide="next">
                <span class="carousel-control-next-icon"></span>
              </a> -->
        </div>
    </div>
  
<div class="row mobilesearc">
               <div class="input-group">
    <input type="text" class="form-control" placeholder="Search..">
    <div class="input-group-append">
      <button class="btn btn-secondary" type="button">
        <i class="fa fa-search"></i>
      </button>
    </div>
  </div>
</div>

<section class="yellow-area pt-5 pb-5" style="background-image: url(<?php echo asset('storage/company/images/yellow_layer.png'); ?>); background-repeat: no-repeat; background-size: cover; background-position: center center;">

    <div class="container">
      
        <div class="row col-md-12">

          
               <div class="col-md-6 " data-aos="fade-up"><h2>Connect</h2>
<ul>
    <li>C2C ecosystem, building America's contractor-  
  to-contractor community</li>
    <li>Lorem ipsum dolor sit amet, consectetur adipiscing 
  elit, sed do eiusmod tempor incididunt ut labore
  et dolore magna aliqua. </li>
</ul>
               </div>
               <div class="col-md-6 text-center" data-aos="fade-up">
                   <img src="{{asset('storage/company/images/VectorSmartObject_old.png')}}" class="img-w-42">
               </div>
           </div>
          
       
    </div>
</section>

 <section class="whiteaft_yellow">
        <div class="container">
            <div class="row col-md-12">
                <div class="col-md-6" data-aos="fade-left"> <img src="{{asset('storage/company/images/map.png')}}" class="d-block w-100 img-fluid" alt="hb"/></div>
                <div class="col-md-5 align-self-center" data-aos="fade-right">
                    <h2>Subhead Goes Here.</h2> 
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore. </p>
                </div>
            </div>
        </div>
</section>

<section class="graybox-area pt-5 pb-5" style="background-image: url(<?php echo asset('storage/company/images/grayblock.png'); ?>); background-repeat: no-repeat; background-size: cover; background-position: center center;">
    <div class="container">
        <div class="row col-md-12">
          
               <div class="col-md-6" data-aos="fade-left">
                <h2>Post</h2>
<ul><li>Tons of Projects to bid on (<a href="{{url('/project-room')}}" class="whcol">Project Room</a>)</li>
<li>Detailed Company information (<a href="{{url('/directory')}}" class="whcol">Directory</a>)</li>
<li>Available positions for the Pros (<a href="{{url('/help-wanted')}}" class="whcol"> Help Wanted </a>)</li>
<li>Materials/equipment for sale (<a href="{{url('/equipment-for-sale')}}" class="whcol">Building Materials & Equipment </a>)</li></ul>
               </div>
               <div class="col-md-6 text-center" data-aos="fade-right">
                   <img src="{{asset('storage/company/images/computer.png')}}" class="img-w-42">
               </div>
           </div>
          
       
    </div>
</section>

 <section class="whiteaft_yellow">
        <div class="container">
            <div class="row ">
                <div class="col-md-6" data-aos="fade-left"> <img src="{{asset('storage/company/images/trolly.png')}}" class="d-block w-100 img-fluid" alt="hb"/></div>
                <div class="col-md-5 align-self-center" data-aos="fade-right">
                    <h2>Subhead Goes Here.</h2> 
<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore. </p>
                </div>
            </div>
        </div>
</section>


<section class="graybox-area pt-5 pb-5" style="background-image: url(<?php echo asset('storage/company/images/bluebox.png'); ?>); background-repeat: no-repeat; background-size: cover; background-position: center center;">
    <div class="container">
        <div class="row col-md-12">
          
               <div class="col-md-6" data-aos="fade-left">
                <h2>Find</h2>
                <ul>
                    <li> Work or projects to bid on (<a href="{{url('/project-room')}}" class="whcol">Project Room</a>)</li>
                    <li>Specialty/local contractors (<a href="{{url('/directory')}}" class="whcol">Project Room and Directory</a>)</li>
                    <li>Employees to hire (<a href="{{url('/help-wanted')}}" class="whcol"> Help Wanted </a>)</li>
                    <li>Product and supplies (<a href="{{url('/equipment-for-sale')}}" class="whcol">Building Materials & Equipment </a>)</li>
                </ul>
               </div>
               <div class="col-md-6 text-center" data-aos="fade-right">
                   <img src="{{asset('storage/company/images/searchicon.png')}}" class="img-w-42">
               </div>
           </div>
          
       
    </div>
</section>

 <section class="whiteaft_yellow lastcommon" data-aos="zoom-in">
        <div class="container">
            <div class="row text-center">
                <div class="col-md-6 align-self-center" > 
                    <button class="btn btn-warning lscbtn">Try it for free <img src="{{asset('storage/company/images/button_hand.png')}}" class="btnimg"></button>
                </div>
                <div class="col-md-6 align-self-center">
                    <h1>60 Day</h1>
                    <h3>Free trail offer.</h3>
                </div>
            </div>
        </div>
</section>



 <style type="text/css">
    h2{font-size: 30px;}
    .whcol{color:#fff;}
    .whcol:hover{color:#fff;}
    body{font-family: erbaum, sans-serif; font-weight: 200;font-style: normal;}
    
    .get_touch .right_inner_content .th-h2{font-family: erbaum, sans-serif; font-weight: 300; font-style: normal;}
    .sliderdata{ color: #172a51; text-align: left;     left: 6% !important;}
    .sliderdata h1{font-weight: 700;     font-size: 48px; line-height: 50px;}
    .sliderdata p{color:#000; font-size:22px !important; }
    .carousel-indicators li{width: 8px !important; height: 8px !important; background-color: #7e7f81 !important; border-radius: 50%; opacity: 1 !important;}
    .carousel-indicators li.active{background-color: #fec701 !important; }
     .img-w-42{width:42%;}
     .graybox-area{color:#fff;}
     .yellow-area li,.graybox-area li{ list-style-type: disc;  font-size: 18px; line-height: 32px; padding: 4px 0px;}
    .whiteaft_yellow{font-size: 20px; padding:60px 0px; }
    .whiteaft_yellow p{font-size: 18px;}
    .lastcommon .lscbtn{padding: 7px 30px; font-size: 18px; text-transform: uppercase; font-weight: bolder;  border: 2px solid #172a51;}
    .sliderdata .lscbtn{ padding: 7px 30px; font-weight: bold; text-transform: uppercase; margin-top:20px;}
    .carousel button.lscbtn { padding: 7px 30px; font-weight: bold; text-transform: uppercase; }
 
    .lastcommon h1,.lastcommon h3{font-weight: 900; color:#172a51;}
    .btnimg{width: 15px; margin: 0px 6px;}
    .mobilesearc{display: none;}

    
    


    @media only screen and (max-width:780px){
        
        body,html{overflow-x:hidden;}
        .get_touch .right_inner_content .th-h2{line-height:37px;}
        .sliderdata .lscbtn {margin-top:0px;}
        .carousel button.lscbtn,.sliderdata .lscbtn {
          padding: 5px 7px;
          font-weight: bold;
          text-transform: uppercase;
          font-size: 10px;
          
      }

      .btnimg {
          width: 11px;
          margin: 0px 6px;
      }

      .mobilesearc{background-color: #000;  padding: 24px 60px; width: 100%; margin: 0px auto;}
        .srchlist{display: none;}
        .mobilesearc{display: block;}
       .search-form .form-group:hover,.search-form .form-group.hover, .search-form .form-group {
          width: 90%;
          border-radius: 4px 25px 25px 4px;
          margin-right: 14px;
          margin-bottom: 8px;
           background-color: #fff;
        }

        .search-form .form-group span.form-control-feedback{right: 14px;}
        .srchlist{order: 2;}
        .header{position: relative;}
        
        .btn-outline-light-custom{border: none; color: #fff; margin-left: 4px !important;      }
        .btn-outline-light-custom .fa{display: none;}
        .sliderdata h1,.sliderdata p{font-size: 14px !important; line-height: 19px !important;}
        .img-w-42{width: 80%;}
        .hb .carousel-caption { bottom: 30px !important; font-size: 14px !important; }
        #navbarTogglerDemo03 .navbar-nav{padding-left: 0px !important;  margin-left: 0px !important;}
    }
  
    @media only screen and (max-width:480px){
        
        .yellow-area li, .graybox-area li {font-size: 18px; line-height: 30px;}

        .hb{     background: #000; }
        .sliderdata h1, .sliderdata p{color:#fff; text-shadow: 1px 1px 2px #525252;}
        .carousel-item img{opacity:0.8;}
        .carousel-indicators{ bottom: -17px;}
      .hb .carousel-caption { bottom: -31px !important; font-size: 14px !important; }
      .carousel button.lscbtn,.sliderdata .lscbtn {text-shadow: 1px 1px 3px #fff; padding: 5px 7px 2px 7px;}
    
    }
 </style>