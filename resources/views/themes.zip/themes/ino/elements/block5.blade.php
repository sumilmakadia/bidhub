<section class="features-area2">
	<div class="row m0 col-height wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
		<div class="col-sm-6 p0 left-inner-content">
			<img src="{{$assets_path_public_bidhub}}subcontractor.png" alt="">
		</div>
		<div class="col-sm-6 p0 right-inner-content">
			<div class="features-content">
				<h2>{{setting('home.location_17')}}</h2>
				<p>{{setting('home.location_18')}}</p>
{{--				<a href="#" class="btn thm-btn">Learn more</a>--}}
			</div>
		</div>
	</div>
	<div class="row m0 col-height two-row wow fadeIn" style="visibility: visible; animation-name: fadeIn;">
		<div class="col-sm-6 p0 left-inner-content">
			<img src="{{$assets_path_public_bidhub}}generalcontractors_2.jpg" alt="">
		</div>
		<div class="col-sm-6 p0 right-inner-content">
			<div class="features-content">
				<h2>{{setting('home.location_20')}}</h2>
				<p>{{setting('home.location_21')}}</p>
			
			</div>
		</div>
	</div>
</section>