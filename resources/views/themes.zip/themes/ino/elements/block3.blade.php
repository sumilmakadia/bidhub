<section class="features-area bg-color">
	<div class="container">
		<div class="row">
			<div class="col-sm-6 f-image wow fadeIn  animated" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeIn;">
{{--				{{setting('home.location_12')}}--}}
				<img class="img-responsive" src="{{$assets_path_public}}image/features-img1.jpg" alt="">
			</div>
			<div class="col-sm-6 wow fadeIn  animated" data-wow-delay="0.3s" data-wow-duration="1500ms" style="visibility: visible; animation-duration: 1500ms; animation-delay: 0.3s; animation-name: fadeIn;">
				<div class="features-content f-pading">
					<h2>{{setting('home.location_13')}}</h2>
					<p>{{setting('home.location_14')}}</p>
{{--					<a href="#" class="btn thm-btn">Learn more</a>--}}
				</div>
			</div>
		</div>
	</div>
</section>
