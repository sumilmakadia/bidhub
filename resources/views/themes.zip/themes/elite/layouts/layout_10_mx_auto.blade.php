<div class="page-wrapper" style="min-height: 149px;">
	<div class="container-fluid">
		<div class="row page-titles">
			<div class="col-md-5 align-self-center">
				<h4 class="text-themecolor">@yield('title')</h4>
			</div>
			<div class="col-md-7 align-self-center text-right">
				<div class="d-flex justify-content-end align-items-center">

				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-12">
				@yield('content')
			</div>
		</div>
	</div>
</div>